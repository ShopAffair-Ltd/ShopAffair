import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Loader2, Copy, Check } from 'lucide-react';
import { generateVirtualAccount, VirtualAccount } from '../../services/paymentService';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeposit: (amount: number) => Promise<void>;
  onAddAuditLog: (action: string, details: string, actor?: string) => void;
  activeUsername: string;
}

export default function DepositModal({ isOpen, onClose, onDeposit, onAddAuditLog, activeUsername }: DepositModalProps) {
  const [depositAmount, setDepositAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [virtualAccount, setVirtualAccount] = useState<VirtualAccount | null>(null);
  const [virtualAccountUnavailable, setVirtualAccountUnavailable] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showOtherMethods, setShowOtherMethods] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setVirtualAccount(null);
    setVirtualAccountUnavailable(false);
    setShowOtherMethods(false);

    generateVirtualAccount()
      .then(setVirtualAccount)
      .catch(() => setVirtualAccountUnavailable(true));
  }, [isOpen]);

  const handleCopyAccountNumber = async () => {
    if (!virtualAccount) return;
    try {
      await navigator.clipboard.writeText(virtualAccount.accountNumber);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
    }
  };

  const handleDeposit = async () => {
    const amt = parseFloat(depositAmount);
    setError(null);
    if (!amt || amt <= 0) {
      setError('Enter a valid amount');
      return;
    }

    setSubmitting(true);
    try {
      onAddAuditLog('WALLET_DEPOSIT_INITIATED', `Started checkout for ₦${amt.toLocaleString()}.`, activeUsername);
      await onDeposit(amt); // redirects the browser to Paystack on success
    } catch (err: unknown) {
      const message =
        (err as { response?: { data?: { message?: string } } })?.response?.data?.message ??
        'Could not start payment. Please try again.';
      setError(message);
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-3xl p-6 max-w-sm w-full border border-slate-100 shadow-2xl relative space-y-4"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center">
              <h3 className="text-lg font-display font-bold text-slate-900">Fund Naira Wallet</h3>
              <p className="text-xs font-sans text-slate-500 mt-1">
                {virtualAccount ? 'Fund your account directly with your dedicated account number below.' : 'Pay by card, bank transfer, or USSD via Paystack checkout.'}
              </p>
            </div>

            {error && (
              <div className="p-3 bg-red-50 text-red-700 rounded-xl border border-red-100 text-xs font-sans font-semibold">
                {error}
              </div>
            )}

            {virtualAccount && (
              <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100 space-y-2.5">
                <p className="text-[10px] font-sans text-purple-700/80 leading-relaxed">
                  Note: transfer any amount to the account below to fund your wallet. Funds reflect automatically within a few minutes.
                </p>

                <div className="bg-white rounded-xl border border-purple-100 p-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <span className="block text-[8px] text-slate-400 font-bold uppercase tracking-wide">Account Number</span>
                    <strong className="font-mono text-base text-slate-900 tracking-wide">{virtualAccount.accountNumber}</strong>
                    <div className="mt-1.5">
                      <span className="block text-[8px] text-slate-400 font-bold uppercase tracking-wide">Bank Name</span>
                      <span className="text-xs font-sans font-bold text-slate-700">{virtualAccount.bankName}</span>
                    </div>
                    <div className="mt-1.5">
                      <span className="block text-[8px] text-slate-400 font-bold uppercase tracking-wide">Account Name</span>
                      <span className="text-xs font-sans font-bold text-slate-700">
                        {virtualAccount.accountName
                          ? virtualAccount.accountName.replace(/ShopAffair\s+(?:Lim|Limited|Ltd)\b/gi, 'ShopAffair')
                          : `ShopAffair/${activeUsername}`}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyAccountNumber}
                    className="shrink-0 w-9 h-9 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-600 flex items-center justify-center transition-colors cursor-pointer"
                    aria-label="Copy account number"
                  >
                    {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {virtualAccountUnavailable && (
              <p className="text-[10px] text-slate-400 leading-relaxed px-1">
                Direct bank transfer accounts aren't set up yet — use checkout below to fund your wallet by card,
                transfer, or USSD instead.
              </p>
            )}

            {virtualAccount && !showOtherMethods && (
              <button
                type="button"
                onClick={() => setShowOtherMethods(true)}
                className="w-full text-center text-xs font-sans font-bold text-purple-600 hover:text-purple-700 cursor-pointer py-1"
              >
                Use other methods (card, USSD, more)
              </button>
            )}

            {(!virtualAccount || showOtherMethods) && (
              <div className="space-y-3 font-sans text-xs">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Enter Deposit amount (₦)</label>
                  <input
                    type="number"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    placeholder="e.g. 50000"
                    disabled={submitting}
                    className="w-full text-sm font-sans px-3 py-2 border border-slate-200 rounded-xl disabled:opacity-60"
                  />
                </div>

                <button
                  onClick={handleDeposit}
                  disabled={submitting}
                  className="w-full py-2.5 bg-green-600 hover:bg-green-700 disabled:opacity-60 text-white font-sans font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Redirecting to checkout...
                    </>
                  ) : (
                    'Continue to Checkout'
                  )}
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}