import crypto from 'crypto';
import { prisma } from '../../config/db';
import { Prisma } from '../../generated/prisma/client.js';
import { env } from '../../config/env';
import { ApiError } from '../../utils/ApiError';
import { notify } from '../notifications/notifications.service';
import { namesLikelyMatch } from '../../utils/nameMatch';
import * as paystack from './providers/paystack.provider';

const generateReference = () => `SF-FUND-${crypto.randomBytes(8).toString('hex')}`;

export const initiateWalletFunding = async (userId: string, amountNaira: number) => {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    throw new ApiError(404, 'User not found');
  }

  const reference = generateReference();
  const amountKobo = Math.round(amountNaira * 100);

  await prisma.walletTransaction.create({
    data: {
      userId,
      type: 'FUNDING',
      provider: 'PAYSTACK',
      amount: amountNaira,
      status: 'PENDING',
      reference
    }
  });

  const { authorization_url, access_code } = await paystack.initializeTransaction({
    email: user.email,
    amountKobo,
    reference,
    callbackUrl: 'https://shops-lake.vercel.app/wallet/callback',
    metadata: { userId, purpose: 'wallet_funding' }
  });

  return { authorizationUrl: authorization_url, accessCode: access_code, reference };
};

export const verifyWalletFunding = async (userId: string, reference: string) => {
  const transaction = await prisma.walletTransaction.findUnique({ where: { reference } });

  if (!transaction || transaction.userId !== userId) {
    throw new ApiError(404, 'Funding transaction not found');
  }

  if (transaction.status === 'SUCCESS') {
    return { alreadyProcessed: true, transaction };
  }

  const verified = await paystack.verifyTransaction(reference);

  if (verified.status !== 'success') {
    await prisma.walletTransaction.update({
      where: { reference },
      data: { status: 'FAILED' }
    });
    throw new ApiError(400, `Payment was not successful (status: ${verified.status})`);
  }

  const result = await prisma.$transaction(async (tx) => {
    const current = await tx.walletTransaction.findUnique({ where: { reference } });
    if (!current || current.status === 'SUCCESS') {
      return { transaction: current };
    }

    const updated = await tx.walletTransaction.update({
      where: { reference },
      data: { status: 'SUCCESS' }
    });

    await tx.user.update({
      where: { id: userId },
      data: { walletBalance: { increment: updated.amount } }
    });

    return { transaction: updated };
  });

  if (result.transaction) {
    await notify({
      userId,
      title: 'Wallet funded',
      message: `₦${Number(result.transaction.amount).toLocaleString()} has been added to your wallet.`,
      type: 'SUCCESS'
    });
  }

  return { alreadyProcessed: false, transaction: result.transaction };
};

export const creditWalletFromWebhook = async (reference: string, amountKobo: number) => {
  const updated = await prisma.$transaction(async (tx) => {
    const transaction = await tx.walletTransaction.findUnique({ where: { reference } });

    if (!transaction) {
      return null;
    }

    if (transaction.status === 'SUCCESS') {
      return null;
    }

    const expectedKobo = Math.round(Number(transaction.amount) * 100);
    if (expectedKobo !== amountKobo) {
      await tx.walletTransaction.update({ where: { reference }, data: { status: 'FAILED' } });
      return null;
    }

    const result = await tx.walletTransaction.update({
      where: { reference },
      data: { status: 'SUCCESS' }
    });

    await tx.user.update({
      where: { id: transaction.userId },
      data: { walletBalance: { increment: result.amount } }
    });

    return result;
  });

  if (updated) {
    await notify({
      userId: updated.userId,
      title: 'Wallet funded',
      message: `₦${Number(updated.amount).toLocaleString()} has been added to your wallet.`,
      type: 'SUCCESS'
    });
  }

  return updated;
};

export const creditWalletFromDvaWebhook = async (params: {
  reference: string;
  amountKobo: number;
  receiverAccountNumber: string | undefined;
}) => {
  const { reference, amountKobo, receiverAccountNumber } = params;

  if (!receiverAccountNumber) {
    console.error(`DVA webhook missing receiver_account_number for reference ${reference}`);
    return null;
  }

  const existing = await prisma.walletTransaction.findUnique({ where: { reference } });
  if (existing) {
    return null;
  }

  const user = await prisma.user.findFirst({ where: { accountNumber: receiverAccountNumber } });
  if (!user) {
    console.error(`DVA webhook: no user found for account number ${receiverAccountNumber} (reference ${reference})`);
    return null;
  }

  const amountNaira = amountKobo / 100;

  const result = await prisma.$transaction(async (tx) => {
    const created = await tx.walletTransaction.create({
      data: {
        userId: user.id,
        type: 'FUNDING',
        provider: 'PAYSTACK',
        amount: amountNaira,
        status: 'SUCCESS',
        reference
      }
    });

    await tx.user.update({
      where: { id: user.id },
      data: { walletBalance: { increment: amountNaira } }
    });

    return created;
  });

  await notify({
    userId: user.id,
    title: 'Wallet funded',
    message: `₦${amountNaira.toLocaleString()} has been added to your wallet.`,
    type: 'SUCCESS'
  });

  return result;
};

export const provisionVirtualAccount = async (userId: string) => {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    throw new ApiError(404, 'User not found');
  }
  if (!user.phoneNumber) {
    throw new ApiError(400, 'Please add a phone number to your profile before generating a virtual account');
  }

  const available = await paystack.isDedicatedAccountAvailable();
  if (!available) {
    throw new ApiError(
      422,
      'Virtual account generation is not enabled on this Paystack account yet. Use "Fund via card/transfer" instead for now.'
    );
  }

  const [firstName, ...rest] = user.name.split(' ');
  const lastName = rest.join(' ') || firstName;

  const customer = await paystack.createOrFetchCustomer({
    email: user.email,
    firstName,
    lastName,
    phone: user.phoneNumber
  });

  const account = await paystack.createDedicatedAccount({ customerCode: customer.customer_code });

  await prisma.user.update({
    where: { id: userId },
    data: {
      accountNumber: account.account_number,
      bankName: account.bank.name
    }
  });

  const cleanedAccountName = (account.account_name || '')
    .replace(/ShopAffair\s+(?:Lim|Limited|Ltd)\b/gi, 'ShopAffair')
    .trim() || `ShopAffair/${user.name || user.username}`;

  return {
    accountNumber: account.account_number,
    accountName: cleanedAccountName,
    bankName: account.bank.name
  };
};

export const listWalletTransactions = async (userId: string, page: number, limit: number) => {
  const [items, total] = await Promise.all([
    prisma.walletTransaction.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit
    }),
    prisma.walletTransaction.count({ where: { userId } })
  ]);

  return { items, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
};

export const getWalletBalance = async (userId: string) => {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { walletBalance: true, promoBalance: true, accountNumber: true, bankName: true }
  });
  if (!user) {
    throw new ApiError(404, 'User not found');
  }
  return user;
};

export const getBankList = async () => {
  return paystack.listBanks();
};

export const resolveWithdrawalAccount = async (accountNumber: string, bankCode: string) => {
  const resolved = await paystack.resolveAccountNumber(accountNumber, bankCode);
  return { accountName: resolved.account_name, accountNumber: resolved.account_number };
};

export const resolveWithdrawalAccountAllBanks = async (accountNumber: string) => {
  const matches = await paystack.resolveAccountAllBanks(accountNumber);
  if (matches.length === 0) {
    throw new ApiError(404, 'Could not find any bank for this account number');
  }
  return { matches };
};

const generateWithdrawalReference = () => `SF-WD-${crypto.randomBytes(8).toString('hex')}`;

export const requestWithdrawal = async (params: {
  userId: string;
  amountNaira: number;
  accountNumber: string;
  bankCode: string;
  bankName: string;
}) => {
  const { userId, amountNaira, accountNumber, bankCode, bankName } = params;

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    throw new ApiError(404, 'User not found');
  }
  if (new Prisma.Decimal(user.walletBalance).lessThan(amountNaira)) {
    throw new ApiError(402, 'Insufficient wallet balance');
  }

  const resolved = await paystack.resolveAccountNumber(accountNumber, bankCode);

  const isVerifiedAccount = !!user.accountNumber && user.accountNumber === accountNumber;
  const isPreviousWithdrawalAccount = !!user.withdrawalAccountNumber && user.withdrawalAccountNumber === accountNumber;
  const nameMatches = namesLikelyMatch(resolved.account_name, user.name);

  if (!isVerifiedAccount && !isPreviousWithdrawalAccount && !nameMatches) {
    throw new ApiError(
      403,
      `This account is registered to "${resolved.account_name}", which doesn't match your verified account name. ` +
      `Withdrawals are only allowed to your verified account or an account in your own name.`
    );
  }

  let recipientCode = user.paystackRecipientCode;
  const isSameAccountAsBefore =
    user.withdrawalAccountNumber === accountNumber && user.withdrawalBankCode === bankCode;

  if (!recipientCode || !isSameAccountAsBefore) {
    const recipient = await paystack.createTransferRecipient({
      name: resolved.account_name,
      accountNumber,
      bankCode
    });
    recipientCode = recipient.recipient_code;
  }

  const reference = generateWithdrawalReference();

  const { transaction } = await prisma.$transaction(async (tx) => {
    const fresh = await tx.user.findUnique({ where: { id: userId } });
    if (!fresh || new Prisma.Decimal(fresh.walletBalance).lessThan(amountNaira)) {
      throw new ApiError(402, 'Insufficient wallet balance');
    }

    await tx.user.update({
      where: { id: userId },
      data: {
        walletBalance: { decrement: amountNaira },
        paystackRecipientCode: recipientCode,
        withdrawalAccountNumber: accountNumber,
        withdrawalAccountName: resolved.account_name,
        withdrawalBankCode: bankCode,
        withdrawalBankName: bankName
      }
    });

    const created = await tx.walletTransaction.create({
      data: {
        userId,
        type: 'WITHDRAWAL',
        provider: 'PAYSTACK',
        amount: amountNaira,
        status: 'PENDING',
        reference
      }
    });

    return { transaction: created };
  });

  try {
    const transfer = await paystack.initiateTransfer({
      amountKobo: Math.round(amountNaira * 100),
      recipientCode: recipientCode!,
      reference,
      reason: `Wallet withdrawal for ${user.username}`
    });

    if (transfer.status === 'success') {
      await prisma.walletTransaction.update({
        where: { reference },
        data: { status: 'SUCCESS' }
      });
      await notify({
        userId,
        title: 'Withdrawal successful',
        message: `₦${amountNaira.toLocaleString()} was sent to ${resolved.account_name} (${bankName}).`,
        type: 'SUCCESS'
      });
    } else {
      await notify({
        userId,
        title: 'Withdrawal processing',
        message: `Your withdrawal of ₦${amountNaira.toLocaleString()} to ${resolved.account_name} is being processed.`,
        type: 'INFO'
      });
    }

    return { transaction, transferStatus: transfer.status, accountName: resolved.account_name };
  } catch (err) {
    await refundFailedWithdrawal(reference);
    throw err;
  }
};

export const refundFailedWithdrawal = async (reference: string) => {
  const updated = await prisma.$transaction(async (tx) => {
    const transaction = await tx.walletTransaction.findUnique({ where: { reference } });
    if (!transaction || transaction.status !== 'PENDING') {
      return null;
    }

    const result = await tx.walletTransaction.update({
      where: { reference },
      data: { status: 'FAILED' }
    });

    await tx.user.update({
      where: { id: transaction.userId },
      data: { walletBalance: { increment: result.amount } }
    });

    return result;
  });

  if (updated) {
    await notify({
      userId: updated.userId,
      title: 'Withdrawal failed',
      message: `Your withdrawal of ₦${Number(updated.amount).toLocaleString()} could not be completed and has been refunded to your wallet.`,
      type: 'WARNING'
    });
  }

  return updated;
};

export const handleTransferWebhookEvent = async (event: string, reference: string) => {
  if (event === 'transfer.success') {
    const transaction = await prisma.walletTransaction.findUnique({ where: { reference } });
    if (transaction && transaction.status === 'PENDING') {
      await prisma.walletTransaction.update({ where: { reference }, data: { status: 'SUCCESS' } });
      await notify({
        userId: transaction.userId,
        title: 'Withdrawal successful',
        message: `₦${Number(transaction.amount).toLocaleString()} has been sent to your bank account.`,
        type: 'SUCCESS'
      });
    }
    return;
  }

  if (event === 'transfer.failed' || event === 'transfer.reversed') {
    await refundFailedWithdrawal(reference);
  }
};

export const STORE_PLANS = {
  TRIAL: {
    id: 'TRIAL',
    name: 'Trial Plan',
    price: 499.9,
    storeCapacity: 5,
    listingLimit: 5,
    durationDays: 30
  },
  STARTER: {
    id: 'STARTER',
    name: 'Starter Plan',
    price: 5000,
    storeCapacity: 1000,
    listingLimit: 250,
    durationDays: 30
  }
} as const;

export type StorePlanId = keyof typeof STORE_PLANS;

const generateSubscriptionReference = () => `SF-SUB-${crypto.randomBytes(8).toString('hex')}`;

export const subscribeToStorePlan = async (userId: string, planId: StorePlanId) => {
  const plan = STORE_PLANS[planId];
  if (!plan) {
    throw new ApiError(400, 'Unknown store plan');
  }

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    throw new ApiError(404, 'User not found');
  }
  if (user.role !== 'seller') {
    throw new ApiError(403, `Only sellers can subscribe to the ${plan.name}`);
  }
  if (user.storePlan === plan.id) {
    throw new ApiError(409, `You already have an active ${plan.name} subscription`);
  }

  const planPrice = new Prisma.Decimal(plan.price);
  const totalAvailable = new Prisma.Decimal(user.walletBalance).plus(user.promoBalance);
  if (totalAvailable.lessThan(planPrice)) {
    throw new ApiError(
      402,
      `Insufficient balance. The ${plan.name} costs ₦${plan.price.toLocaleString()}, and your wallet + promo balance total ₦${totalAvailable.toFixed(2)}.`
    );
  }

  const reference = generateSubscriptionReference();

  const subscription = await prisma.$transaction(async (tx) => {
    const fresh = await tx.user.findUnique({ where: { id: userId } });
    if (!fresh || fresh.storePlan === plan.id) {
      throw new ApiError(409, `You already have an active ${plan.name} subscription`);
    }

    const freshPromoBalance = new Prisma.Decimal(fresh.promoBalance);
    const freshWalletBalance = new Prisma.Decimal(fresh.walletBalance);
    const freshTotal = freshWalletBalance.plus(freshPromoBalance);

    if (freshTotal.lessThan(planPrice)) {
      throw new ApiError(402, 'Insufficient balance');
    }

    // Spend promo balance first, since it can ONLY be used for in-app
    // services like this — falling back to regular wallet balance for
    // whatever the promo balance doesn't cover.
    const fromPromo = freshPromoBalance.lessThan(planPrice) ? freshPromoBalance : planPrice;
    const fromWallet = planPrice.minus(fromPromo);

    await tx.user.update({
      where: { id: userId },
      data: {
        promoBalance: { decrement: fromPromo },
        walletBalance: { decrement: fromWallet },
        isPro: true,
        storePlan: plan.id
      }
    });

    await tx.walletTransaction.create({
      data: {
        userId,
        type: 'SUBSCRIPTION',
        provider: 'MANUAL',
        amount: plan.price,
        status: 'SUCCESS',
        reference
      }
    });

    await tx.product.updateMany({
      where: { sellerId: userId },
      data: { isListed: true }
    });

    return tx.subscription.create({
      data: {
        userId,
        plan: plan.id,
        amount: plan.price,
        reference,
        expiresAt: new Date(Date.now() + plan.durationDays * 24 * 60 * 60 * 1000)
      }
    });
  });

  await notify({
    userId,
    title: `${plan.name} activated`,
    message: `You're now on the ${plan.name}. You can list up to ${plan.listingLimit} products.`,
    type: 'SUCCESS'
  });

  return subscription;
};

export const SELLER_PRO_PRICE = STORE_PLANS.STARTER.price;

export const subscribeToSellerPro = async (userId: string) => subscribeToStorePlan(userId, 'STARTER');

export const getSubscriptionStatus = async (userId: string) => {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { isPro: true, storePlan: true }
  });
  if (!user) {
    throw new ApiError(404, 'User not found');
  }

  const latest = await prisma.subscription.findFirst({
    where: { userId, active: true },
    orderBy: { createdAt: 'desc' }
  });

  return { isPro: user.isPro, storePlan: user.storePlan, subscription: latest };
};

export const listAllWithdrawals = async (page: number, limit: number) => {
  const [items, total] = await Promise.all([
    prisma.walletTransaction.findMany({
      where: { type: 'WITHDRAWAL' },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
      include: { user: { select: { username: true, name: true, withdrawalBankName: true, withdrawalAccountNumber: true, withdrawalAccountName: true } } }
    }),
    prisma.walletTransaction.count({ where: { type: 'WITHDRAWAL' } })
  ]);
  return { items, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
};

export const listAllTransactions = async (page: number, limit: number) => {
  const [items, total] = await Promise.all([
    prisma.walletTransaction.findMany({
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
      include: { user: { select: { username: true } } }
    }),
    prisma.walletTransaction.count()
  ]);
  return { items, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
};